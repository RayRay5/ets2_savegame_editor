There are still some features missing and some old features haven't been added yet, due to various reasons of a change in the way the saveeditor works.
	
	IMPORTANT NOTE: The "Common Utilities" form provides lots of the old functions that you know from Version 1.x . However they are working at the moment, but don't change any data.
	Using them is senseless, because they don't have any impact. Use saveeditor v1.x or use the Unit editor and edit the data manually.

The new version has been tested with several savegames and was found to be working in most cases.
If you find a bug, report it to me, using the TMP Forums or here on Github.
If you encounter a crash, recreate it, and provide me the log file that will automatically be generated with the beta versions.
If you use a final release, you have to manually enable logging in the settings (function not implementent yet, due to the fact that V2 is only available as a beta :trollface:)

The program wont start without the .dll file in the same folder.
It will only start if there is a lang folder and a config.txt file

This program was written by www.github.com/RayRay5
Licensed under GNU General Public License V3 (2007)
License applies to all code and binarys (executables and libary files) (exe and dll files)