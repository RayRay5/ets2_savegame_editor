This library was written by www.github.com/RayRay5
Licensed under GNU General Public License V3 (2007)
License applies to all code and binarys (executables and libary files) (exe and dll files)