You can change the language by adding a editing the config.txt file.
Important: "lang: " has to be in there all the time.
Programm will load a file called "lang_en.txt" or similar to read the translation from. For custom translation, replace "en" with your lang code